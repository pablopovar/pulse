# Pulse App audit exclusions

## Outside scope

Everything outside `pulse-app/` is excluded: all of `opengsc-repo/`, repository-root files, root Compose configuration, `docs/`, `packets/`, `scripts/`, `reports/`, and the `audit-app` alias. None receives audit batches or coverage rows.

## Omitted inside pulse-app/

Zero-byte package initializers contain no executable logic:

- `pulse-app/audits/__init__.py`
- `pulse-app/audits/geo_aeo/__init__.py`
- `pulse-app/crawlers/__init__.py`
- `pulse-app/integrations/__init__.py`
- `pulse-app/integrations/dataforseo/__init__.py`
- `pulse-app/services/__init__.py`

## Context only inside pulse-app/

- `pulse-app/README.md`
- `pulse-app/reports/REPORT_CONTRACT.md`
- `pulse-app/static/skins/README.md`

Tests, fixtures, migrations, requirements, Dockerfile, entrypoint, templates, CSS and browser JavaScript within pulse-app remain in scope. Pulse-owned integration adapters are in scope; dependency internals are not.
