# Pulse App — comparison and integration runs

Primary B001–B067 run IDs remain stable. These are mandatory additional runs, not optional suggestions. C runs are cross-file comparisons: their purpose requires more than four context files in some cases; inspect pairs in subpasses. They do not replace the small primary batches.

## C01. Web/worker domain parity

Compare normalization, imported site fields, case/IDNA/ports, suppression and sync side effects. Exercise the same domain fixtures through both paths. Record intended differences; do not assume matching names imply identical contracts.

Prerequisite primary coverage: B008, B009, B010, B011, B012, B013, B016, B021, B023.

Files:
- `pulse-app/app.py`
- `pulse-app/services/domain_registry.py`
- `pulse-app/services/url_policy.py`
- `pulse-app/jobs/workflows.py`

Completion: document actual callers, intended divergence, fixture results and remaining uncertainty. Status: planned.

## C02. Audit persistence duplication and reachability

Trace audit_worker and both persistence/aggregation implementations. Establish callers across all scoped source, tests, decorators and callbacks before calling a chain dead. Compare SQL, transactions, errors and summary denominators.

Prerequisite primary coverage: B008, B009, B010, B011, B012, B013, B019, B021, B035.

Files:
- `pulse-app/app.py`
- `pulse-app/services/audit_execution.py`
- `pulse-app/jobs/handlers.py`
- `pulse-app/jobs/workflows.py`

Completion: document actual callers, intended divergence, fixture results and remaining uncertainty. Status: planned.

## C03. Manual AI storage, projection and governance

Compare four stored phase/state combinations with the two active report states; validate provider/question denominators and stale analysis. Establish actual callers for cross_model/question_governance; distinguish dormant schema/API from active product behavior.

Prerequisite primary coverage: B008, B009, B010, B011, B012, B013, B038, B039, B040, B043, B044, B045.

Files:
- `pulse-app/services/manual_ai_sources.py`
- `pulse-app/services/manual_ai_report.py`
- `pulse-app/services/manual_ai_payload.py`
- `pulse-app/reports/question_governance.py`
- `pulse-app/reports/cross_model.py`
- `pulse-app/reports/web_report.py`
- `pulse-app/app.py`

Completion: document actual callers, intended divergence, fixture results and remaining uncertainty. Status: planned.

## C04. Publication mechanisms and execution identity

Enumerate every caller of create_report_session and publish_report_if_owned, including tests. Test publish=True versus staged publication. Interleave two domain refreshes and prove collection uses the intended execution, not merely a coherent latest audit/crawl pair.

Prerequisite primary coverage: B021, B043, B044, B045, B046.

Files:
- `pulse-app/reports/web_report.py`
- `pulse-app/jobs/publication.py`
- `pulse-app/jobs/workflows.py`
- `pulse-app/services/report_data.py`

Completion: document actual callers, intended divergence, fixture results and remaining uncertainty. Status: planned.

## C05. Parallel HTTP capture and parsing

Compare crawler and audit requests, robots behavior, supporting files, MIME/redirect limits, timestamps, hashing and parsing. Test a page changing between captures; identify which evidence supports each claim. Separate configured provider HTTP clients from arbitrary-URL fetching.

Prerequisite primary coverage: B023, B024, B028, B029, B030, B031, B032, B033, B034, B035.

Files:
- `pulse-app/crawlers/seo.py`
- `pulse-app/audits/geo_aeo/engine.py`
- `pulse-app/audits/geo_aeo/service.py`
- `pulse-app/services/page_discovery.py`
- `pulse-app/services/safe_fetcher.py`
- `pulse-app/services/resource_outcome.py`

Completion: document actual callers, intended divergence, fixture results and remaining uncertainty. Status: planned.

## C06. Wrappers, aliases and alternate entry paths

Classify delegates versus substantive duplicates. Trace sitemap compatibility helpers, extended_sources enrichment, source detection and aliases. Search all scoped templates/JS/tests plus imports and callbacks; unresolved dynamic references remain uncertain.

Prerequisite primary coverage: B008, B009, B010, B011, B012, B013, B016, B018, B024, B041.

Files:
- `pulse-app/app.py`
- `pulse-app/services/source_inventory.py`
- `pulse-app/services/domain_company.py`
- `pulse-app/services/page_discovery.py`
- `pulse-app/reports/extended_sources.py`
- `pulse-app/integrations/opengsc_adapter.py`

Completion: document actual callers, intended divergence, fixture results and remaining uncertainty. Status: planned.

## C07. Configuration, startup and filesystem parity

Create configuration table for RESEARCH_DB/SEO_DB/REPORTS_DIR/skin/provider/security settings across entry points. Test env unset/set/malformed, migrations and concurrent startup. Verify skin/temp/export paths, domain deletion, traversal, atomic writes and cleanup. app.py and workflows currently have different fallback RESEARCH_DB paths; assess launch-dependent impact.

Prerequisite primary coverage: B002, B003, B008, B009, B010, B011, B012, B013, B016, B019, B021, B053.

Files:
- `pulse-app/app.py`
- `pulse-app/Dockerfile`
- `pulse-app/entrypoint.sh`
- `pulse-app/db/migrate.py`
- `pulse-app/jobs/worker.py`
- `pulse-app/jobs/workflows.py`
- `pulse-app/services/domain_skin.py`
- `pulse-app/reports/observation_export.py`

Completion: document actual callers, intended divergence, fixture results and remaining uncertainty. Status: planned.

## C08. Ownership, contracts and test blind spots

Reconcile registered table owners with actual scoped modules/writers. Enumerate nested registered routes as well as top-level app routes. Check indirect GET network work, route-method conflicts and contract assertions; architectural tests are partial evidence, not completeness proofs.

Prerequisite primary coverage: B007, B008, B009, B010, B011, B012, B013, B014, B016, B025, B028, B029, B030, B031, B041.

Files:
- `pulse-app/db/ownership.py`
- `pulse-app/reports/REPORT_CONTRACT.md`
- `pulse-app/tests/test_architecture_cleanup.py`
- `pulse-app/tests/test_application_services.py`
- `pulse-app/tests/test_request_paths_no_discovery_io.py`
- `pulse-app/app.py`
- `pulse-app/crawlers/seo.py`
- `pulse-app/integrations/dataforseo/extension.py`
- `pulse-app/services/domains.py`

Completion: document actual callers, intended divergence, fixture results and remaining uncertainty. Status: planned.

## Integration execution order

Run I01–I07 after the relevant B and C runs. Run I08 last. Each integration run must cite the exact route/job matrix rows exercised, fixture data, commands/results and untested cases.

- **I01** — Authorization across every registered route/method
- **I02** — Worker lifecycle, concurrency and ownership fencing
- **I03** — Discovery/crawl/audit capture and evidence consistency
- **I04** — Snapshot/history/HTML/export/localization parity
- **I05** — Manual AI evidence, analysis and governance
- **I06** — Pulse-owned external adapter contracts with local fixtures
- **I07** — Configuration/startup/migration/filesystem behavior
- **I08** — Final coverage, contract and findings reconciliation
