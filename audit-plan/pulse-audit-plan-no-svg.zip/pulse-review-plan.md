# Pulse App — architecture and audit execution plan

Repository: pablopovar/pulse. Pinned commit: `5b4148c0e24030494fca8609e0180ab3a4b0fc9d`. Scope revised 18 October 2026.

## Scope and status

**Only `pulse-app/` is in scope.** OpenGSC, root deployment configuration, root scripts, root documentation, packets and every other repository path are excluded. No OpenGSC internal code review or end-to-end certification is included. Pulse's own OpenGSC adapter remains in scope because it is Pulse App code; its external database is treated as an untrusted dependency contract and tested with local fixtures.

Architecture reconnaissance and the revised audit plan are complete. Defect-audit runs remain planned. No implementation changes or application tests have been performed for this revision.

The scoped inventory has **149 tracked files: 140 audit targets, 3 context documents and 6 zero-byte omissions**. There are **67 primary review runs** in 19 functional groups, plus eight explicit comparison runs and eight Pulse-only integration runs. Every primary run contains at most four files. Selected long files use consecutive 400-line windows; shorter dense files retain a dedicated whole-file batch. Comparison runs deliberately revisit related files and do not count as additional primary coverage.

## Exclusions first

See `pulse-audit-exclusions.md` for the explicit outside-scope folders and exact internal omitted/context paths. No outside-scope file appears in the batch list or coverage manifest. Pulse App's tests, fixtures, schema migrations, requirements, Dockerfile, entrypoint, templates, styles and browser code remain included.

## High-level flow diagram

```mermaid
flowchart TD
  Operator["Operator"] --> Web["Flask routes and security boundary"]
  Client["Client capability / optional password"] --> Web
  Web --> Workspaces["Domains, research, keywords and source settings"]
  Web --> Manual["Manual AI evidence ingestion"]
  Web --> Queue[("Pulse SQLite: durable jobs")]
  Queue --> Worker["Lease-owning worker"]
  Worker --> Capture["Discovery, crawl and separate GEO/AEO capture"]
  Worker --> Analysis["Optional AI interpretation"]
  Worker --> Reports["Collect sources, snapshot and publish"]
  Workspaces --> Data[("Pulse data and immutable observations")]
  Manual --> Data
  Capture --> Data
  Analysis --> Data
  Data --> Reports
  Web --> DFS["DataForSEO client and controls"]
  DFS --> Data
  External[("External OpenGSC DB; outside audit")] -->|"Pulse read-only adapter"| Workspaces
  External -->|"Pulse read-only adapter"| Reports
  Reports --> Data
  Data --> View["History, interpretation, discussion and HTML/exports"]
  Web --> View
  Skin[("Domain skin files")] --> View
  Workspaces --> Skin
  Capture -->|"SafeFetcher HTTP"| Sites["External audited websites"]
  Analysis -->|"configured API client"| Providers["External AI / data providers"]
  DFS -->|"configured API client"| Providers
```

External nodes describe interfaces exercised by Pulse App; their implementations are outside the audit. Runtime hosting, root Compose settings, OpenGSC behavior and live provider correctness are not verified by this scope.

### Pulse report-refresh sequence

1. `POST /d/<domain>/reports/full` enqueues `report_refresh`. The request returns to the reports page; it does not execute the full workflow synchronously.
2. The worker claims the job, renews its lease, and dispatches `run_report_refresh`. The workflow loads crawl policy and client scope, then runs an initial bounded crawl. Discovery inventories and frontier selection determine eligible pages; URL presence is not itself an instruction to fetch.
3. The crawler fetches robots and resources, persists pages/issues/evidence and frontier state. The refresh selects successfully fetched pages that match `site_page`. It withholds publication when prerequisites or minimum evidence fail.
4. `run_audit` calls `run_audit_pages`, which calls the GEO/AEO service/engine. **The engine fetches page HTML again.** Crawl evidence and scoring capture therefore must not be assumed to share identical bytes or observation time. Structured capture, findings and summaries are stored in Pulse SQLite.
5. `collect_report_data` assembles stored crawl/audit data plus OpenGSC reads. Collection first selects the latest eligible domain audit, then looks for the crawl matching that audit execution; legacy linkage is recorded separately. The workflow does not pass its expected audit/run IDs into collection. C04 and I02 must verify current-job identity under concurrency; a coherent audit/crawl pair alone does not prove current-job provenance. Selected-source inventory and manual AI projection are added.
6. `create_report_session(..., publish=False)` stores the snapshot/configuration/version metadata. `publish_report_if_owned` checks the job, lease, worker, domain and report linkage in a write transaction before updating `domain_report` and publication state.
7. Eligible background crawl work is scheduled separately. Its later evidence is not retroactively inserted into an existing snapshot; a later report observation must use it explicitly.
8. Report GET loads the saved session, derives history and view data, renders `full_report.html`, and localizes the presentation. JSON/CSV/PDF exports go through `observation_export.py`; PDF generation uses `full_pdf.py`.

“Immutable observation” is narrower than “every byte on the page is frozen.” The view loads human interpretation and discussion notes separately, and history/navigation/view logic are derived at read time. Audit I04 must verify that these overlays and code-version changes cannot silently rewrite the meaning of historical evidence.

### Manual AI evidence sequence

The operator collects public-facing ChatGPT, Claude and Gemini answers outside the automated capture flow, then pastes them into the manual AI source UI. `manual_ai_sources.py` stores raw state; `manual_ai_payload.py` parses it; `manual_ai_report.py` projects the active retrieval-enabled state for two phases. The current completeness model expects six provider-phase runs and 24 question answers. Optional `manual_ai_analysis` jobs take a source snapshot and parameter set, call the configured analysis provider, then update analysis state under a worker ownership check. Report construction copies manual AI evidence into the report snapshot. OpenGSC's API-based AEO tracker is a separate evidence stream and must not be conflated with these manual runs.

`reports/cross_model.py` and `question_governance.py` are retained in scope. Their presence alone does not establish that all of their functions participate in the active manual projection; the audit must establish actual reachability and legacy contracts.


## Functional groups and batch ranges

| Group | Files | Runs |
| --- | ---: | --- |
| 01. Deployment and dependencies | 5 | B001–B002 |
| 02. Pulse schema and storage | 19 | B003–B007 |
| 03. Pulse HTTP shell and route contracts | 3 | B008–B014 |
| 04. Pulse security and client access | 4 | B015–B015 |
| 05. Pulse domain lifecycle and presentation settings | 6 | B016–B017 |
| 06. Pulse OpenGSC adapter | 3 | B018–B018 |
| 07. Pulse durable job lifecycle | 5 | B019–B020 |
| 08. Pulse workflow and publication | 4 | B021–B022 |
| 09. Pulse URL and outbound HTTP boundary | 4 | B023–B023 |
| 10. Pulse page discovery and reconciliation | 7 | B024–B025 |
| 11. Pulse crawl selection and frontier | 7 | B026–B027 |
| 12. Pulse crawler and evidence | 5 | B028–B032 |
| 13. Pulse GEO/AEO audit and scoring | 11 | B033–B037 |
| 14. Pulse manual AI evidence and analysis | 9 | B038–B040 |
| 15. Pulse source selection and paid integration | 7 | B041–B042 |
| 16. Pulse report collection and immutable sessions | 3 | B043–B046 |
| 17. Pulse findings, history and prioritization | 5 | B047–B049 |
| 18. Pulse report presentation and export | 14 | B050–B061 |
| 19. Pulse research and operator UI | 19 | B062–B067 |

## Batch execution procedure

Use `pulse-audit-runs.md` in numeric order. For each run:

1. Verify the commit. Read the exact files/windows, enclosing definitions, Pulse-owned callers, schemas and relevant tests. Carry unresolved findings forward.
2. Trace input → authentication/validation → storage or external side effects → output. Check domain/site scoping, failures, timing, provenance and ownership.
3. Exercise targeted tests with isolated local fixtures. Record actual commands/results. Avoid live provider costs, production data or external mutations.
4. Record severity, confidence, file/line, trigger, impact and minimal reproduction for each finding. Separate verified defects from hypotheses.
5. Update a ledger containing run ID, commit, completed files/windows, consulted context, findings, checks, results, limitations and next run. Statuses: planned / in_progress / blocked / complete.

For split files, include the enclosing function as context and perform whole-file synthesis at the final window. Cross-reference app.py routes during each relevant flow even though app.py has its own primary coverage. Integration fixtures establish expected external contracts, not the correctness of external services.

## Comparisons and integration runs

`pulse-comparison-runs.md` defines mandatory C01–C08 paired/reachability reviews and I01–I08 integration checks. Complete B001–B067, then C01–C08 in order; a C run may begin once its listed prerequisites are complete. Integration I01–I07 follows the relevant primary/comparison work; I08 is the final gate. Findings in the prior audit are investigation seeds, not pre-certified application defects.

| Run | Explicit comparison |
| --- | --- |
| C01 | Web versus worker domain lookup, normalization and synchronization. |
| C02 | Duplicate audit persistence/aggregation and apparently unused legacy audit worker. |
| C03 | Manual storage/report projections, governance and cross-model reachability. |
| C04 | Direct versus fenced publication; intended execution versus latest audit/crawl selection. |
| C05 | Independent HTTP captures, parsers, robots policy and evidence provenance. |
| C06 | Delegating wrappers versus duplicate implementations; unused-code candidates and alternate enrichment/discovery paths. |
| C07 | Entry-point configuration defaults, startup migrations and filesystem behavior. |
| C08 | Declared table ownership, report contracts, nested registration and test blind spots. |

All eight integration runs and their names are enumerated in `pulse-comparison-runs.md` and the manifest. I06 covers external adapters only; I07 covers configuration/startup/filesystem; I08 is a separate final reconciliation.

## Deliverables and validation

- `pulse-audit-runs.md`: full ordered list of exact files and line ranges.
- `pulse-audit-coverage.csv`: one row per scoped tracked file, including blob SHA, disposition and run IDs.
- `pulse-audit-manifest.json`: machine-readable scope, runs and reconnaissance retrieval provenance.
- `pulse-audit-exclusions.md`: exclusions and context paths.
- `pulse-architecture.mmd`: standalone Mermaid source.

Validation checks exact coverage against the pinned Git tree's pulse-app/ entries, no external paths, assignments for all audit files, no assignments for omitted/context files, at most four files per batch and gap-free split-file line coverage. Retrieval provenance records reconnaissance inputs; retrieval alone does not mark a defect audit complete. Reinventory before auditing a different commit.

## Route and job coverage matrices

`pulse-route-matrix.csv` enumerates **93 declared route registrations**, recursively including registrations inside `register_crawler`, `register_delete_domain` and `register_dataforseo_extension`. Each row gives endpoint, source line, primary batch, statically reachable local functions, candidate SQL tables, template/static assets, literal queued job types and candidate tests. Declared methods are explicit; implicit Flask HEAD/OPTIONS and framework static routing must be added during I01. Runtime URL-map reconciliation is required before calling route coverage complete.

`pulse-job-matrix.csv` enumerates **all seven HANDLERS entries** with implementation location, primary batches, candidate reachable code/tables and route enqueue relationships. Worker-to-worker scheduling and report_refresh's direct subworkflow calls must be traced too; route enqueue rows do not describe the entire job graph.

These are static navigation matrices, not validated end-to-end proofs. Imported aliases and ordinary local function calls are followed; callbacks, injected functions, dynamic dispatch/imports, generated SQL/table names, computed templates/assets, relative-import resolution and external calls can be incomplete. Candidate tests are starting points by functional ownership, not assertions that they exercise a route. During B/C/I runs, confirm or correct every link and record unresolved edges. Empty table/template fields mean no statically resolved value, not no side effects. SQL-name candidates must be checked against actual statements and the ownership registry.

## Flow-to-component review map

All paths below are beneath pulse-app/. Use the CSV matrices for exact route rows and primary batch IDs.

| Flow | Entry and components | Storage / UI | Required runs |
| --- | --- | --- | --- |
| Domain lifecycle | app.py domain creation/sync; services/domain_registry.py; services/domains.py | dashboard_domain, suppression and deletion dependencies; domain templates | B016–B018, C01, C07, I01, I07 |
| Research and keywords | app.py research/wanted/page/keyword/taxonomy routes | keyword/page/tag/note tables; research, wanted and workspace templates; taxonomy.js | B008–B014, B062–B067, I01, I08 |
| Discovery and crawling | registered crawler routes; jobs/store.py; jobs/workflows.py; page_discovery.py; crawl_frontier.py; crawlers/seo.py | discovery, inventory/frontier, run/page/evidence tables; crawl UI | B019–B032, C05–C06, I02–I03 |
| GEO/AEO audit | app.py audit routes; audit_execution.py; audits/geo_aeo service/engine | audit run/page/signal/summary/state; GEO/AEO templates and JS | B033–B037, C02, C05, I03 |
| Manual AI | source routes; manual_ai_sources/payload/report; manual_ai_analysis; worker | raw provider states, analysis runs; manual AI UI | B038–B040, C03, I05 |
| DataForSEO | registered extension routes; connector | project settings, usage, snapshots; dataforseo.html | B041–B042, I01, I06 |
| Report publication | report_refresh; report_data; web_report; publication | report_session, domain_report, source/config snapshots | B021–B022, B043–B049, C04, I02, I04 |
| Report delivery and collaboration | management/public report routes; report_collaboration; observation_export; full_pdf; localization | report notes/replies/interpretation and immutable observations; full_report.html and JS | B050–B061, I01, I04 |
| Domain skins and files | settings/skin routes; domain_skin; PDF/export temporary files | CSS/settings files, theme variants and temporary export lifecycle | B016–B017, B050–B061, C07, I07 |

## Mandatory contract and completion checks

REPORT_CONTRACT.md is required context, not an optional excluded document. Map each requirement to evidence in these runs:

| Requirement | Owning review |
| --- | --- |
| FAIL/PARTIAL versus MANUAL_REVIEW/NOT_APPLICABLE/DATA_UNAVAILABLE; legacy UNKNOWN normalization | B033–B037, B043–B049, I04 |
| Exact page/check identity; missing assessment is not resolution; material-event history and unique-page movements | B047–B049, I04 |
| Implemented versus verified recommendations, root-cause evidence retention and required finding fields | B043–B049, I04 |
| Current/baseline pointer versus immutable observations; completed unchanged monitoring runs | B021–B022, B043–B046, C04, I02, I04 |
| Coverage states and timestamps; GA4 versus Clarity; bounded GSC dates/click labels | B018, B041–B049, I06 |
| Same-execution provenance and limits for legacy data; expected current execution under concurrency | B021–B022, B043–B046, C04, I02–I03 |
| Value-to-fix-v2 factors, missing exposure and zero nonissue scores | B047–B049, I04 |
| Provider/state/question denominators; model-prior versus retrieval; unsupported causal/truth claims | B038–B040, C03, I05 |
| Report-quality errors block relevant exports; HTML/PDF/CSV/JSON agree | B043–B061, I04 |

A primary batch is complete only with recorded files/windows, validated caller relationships, applicable schema/contracts, commands/results or an explicit inability to execute, findings and unresolved edges. An inability to execute leaves verification blocked or explicitly qualified; static reading must not be presented as a test pass.

I08 may close the audit only when: all 140 primary targets and split ranges are accounted for; all 93 declared registrations are reconciled with a runtime or explicitly qualified route inventory; all seven handlers are reviewed; C01–C08 and I01–I07 have recorded outcomes; every contract row has evidence or a gap; duplicate findings are consolidated; unused-code claims include reachability limits; and the final diagram reflects verified architecture. State any blocked runtime validation in the final opinion.

## Amendment record

This revision preserves B001–B067 and the 149-file scope. It expands the diagram, adds route/job/flow matrices, adds C01–C08, expands integration work to I01–I08, qualifies report execution provenance and sets explicit completion gates. No application source was changed. Matrix/manifest consistency was checked locally; application defect-audit runs and runtime verification remain planned.

## Visual and concise summary

See `pulse-architecture.svg` for the scalable architecture diagram and `pulse-audit-summary.md` for the concise proposal. The SVG preserves every node and directed edge in `pulse-architecture.mmd`.
