# Pulse App audit proposal

Audit only `pulse-app/` at commit `5b4148c0e24030494fca8609e0180ab3a4b0fc9d`. OpenGSC internals and everything outside that directory are excluded; Pulse-owned integration adapters remain included.

1. Review 140 source, configuration, migration, UI and test files in 67 small batches.
2. Compare parallel implementations in eight focused runs: domains, audit persistence, manual AI, publication, capture, wrappers, configuration and ownership/contracts.
3. Validate the complete flows in eight integration reviews, using the 93 declared route registrations and seven job handlers as coverage checkpoints.

Priorities are authorization, durable job recovery and concurrency, report provenance and historical truth, evidence/scoring consistency, configuration parity and filesystem handling. Use isolated fixtures and record actual test results, unresolved links and verification limits.

Deliver an evidence-backed findings report, reconciled architecture diagram and completed coverage ledger. Review does not include implementing fixes. The plan is complete; detailed code audits and runtime verification remain planned.

The SVG preserves the Mermaid diagram's nodes and directed edges. Dashed nodes are external dependencies whose implementations are outside this audit; internal arrows summarize flows, not exhaustive call sequences.
