# Pulse App — ordered audit runs

Commit: `5b4148c0e24030494fca8609e0180ab3a4b0fc9d`. Scope: `pulse-app/` only.

Run in numeric order. At most four primary files per run. Large files use consecutive 400-line windows; include enclosing definitions and caller contracts as context. These are planned defect audits, not completed reviews.

## 01. Deployment and dependencies

Ports, mounts, startup, migrations, secrets, reproducibility, dependency supply chain and update/backup behavior.

### B001

- `pulse-app/.env.example`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B002

- `pulse-app/Dockerfile`
- `pulse-app/entrypoint.sh`
- `pulse-app/pytest.ini`
- `pulse-app/requirements.txt`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## 02. Pulse schema and storage

Schema ownership, migration ordering/backfills, constraints, foreign keys, WAL, read-only access and rollback.

### B003

- `pulse-app/db/__init__.py`
- `pulse-app/db/migrate.py`
- `pulse-app/db/migrations/0001_baseline.sql`
- `pulse-app/db/migrations/0002_complete_lazy_schema.sql`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B004

- `pulse-app/db/migrations/0003_legacy_data_backfills.sql`
- `pulse-app/db/migrations/0004_durable_jobs.sql`
- `pulse-app/db/migrations/0005_worker_workflows_idempotency.sql`
- `pulse-app/db/migrations/0006_page_discovery.sql`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B005

- `pulse-app/db/migrations/0007_crawl_frontier_and_job_controls.sql`
- `pulse-app/db/migrations/0008_client_report_access.sql`
- `pulse-app/db/migrations/0009_report_quick_links.sql`
- `pulse-app/db/migrations/0010_resource_outcomes.sql`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B006

- `pulse-app/db/migrations/0011_page_types.sql`
- `pulse-app/db/migrations/0012_crawler_evidence.sql`
- `pulse-app/db/migrations/0013_applicability_policy.sql`
- `pulse-app/db/migrations/0014_crawl_robots_policy.sql`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B007

- `pulse-app/db/ownership.py`
- `pulse-app/db/sqlite.py`
- `pulse-app/tests/test_migrations_and_sqlite.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## 03. Pulse HTTP shell and route contracts

Trace every route and helper, registration, request validation, response behavior and cross-domain identifiers. Reconcile extracted services with remaining inline code.

### B008

- `pulse-app/app.py` — lines 1–400

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B009

- `pulse-app/app.py` — lines 401–800

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B010

- `pulse-app/app.py` — lines 801–1200

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B011

- `pulse-app/app.py` — lines 1201–1600

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B012

- `pulse-app/app.py` — lines 1601–2000

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B013

- `pulse-app/app.py` — lines 2001–2118

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B014

- `pulse-app/tests/test_application_services.py`
- `pulse-app/tests/test_architecture_cleanup.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## 04. Pulse security and client access

Management authentication, proxy assertions, CSRF, public capabilities, optional passwords, revocation, exports and static/skin exceptions.

### B015

- `pulse-app/services/public_report_access.py`
- `pulse-app/services/security_boundary.py`
- `pulse-app/tests/test_client_monitoring_and_access.py`
- `pulse-app/tests/test_security_boundary.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## 05. Pulse domain lifecycle and presentation settings

Domain normalization, import/suppression, deletion cleanup, company identity and custom CSS handling.

### B016

- `pulse-app/services/domain_company.py`
- `pulse-app/services/domain_registry.py`
- `pulse-app/services/domain_skin.py`
- `pulse-app/services/domains.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B017

- `pulse-app/tests/test_domain_deletion.py`
- `pulse-app/tests/test_domain_skin.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## 06. Pulse OpenGSC adapter

Read-only SQL schema compatibility, missing tables, time windows, normalization and correct site/domain scoping.

### B018

- `pulse-app/integrations/opengsc_adapter.py`
- `pulse-app/tests/test_opengsc_adapter.py`
- `pulse-app/tests/test_opengsc_schema_isolation.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## 07. Pulse durable job lifecycle

Atomic claim, leases, retries, heartbeat ownership, pause/resume/cancel and crash recovery; distinguish job state from workflow state.

### B019

- `pulse-app/jobs/__init__.py`
- `pulse-app/jobs/handlers.py`
- `pulse-app/jobs/store.py`
- `pulse-app/jobs/worker.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B020

- `pulse-app/tests/test_jobs.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## 08. Pulse workflow and publication

Stage transitions, idempotency, publication withholding, bounded crawl scope, ownership fencing, current/baseline pointers and background scheduling.

### B021

- `pulse-app/jobs/publication.py`
- `pulse-app/jobs/workflows.py`
- `pulse-app/tests/test_no_flask_daemon_workflows.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B022

- `pulse-app/tests/test_worker_workflows_idempotency.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## 09. Pulse URL and outbound HTTP boundary

SSRF, DNS rebinding, redirects, private addresses, timeout/body limits, canonical identity and hostname equivalence.

### B023

- `pulse-app/services/safe_fetcher.py`
- `pulse-app/services/url_policy.py`
- `pulse-app/tests/test_safe_fetcher.py`
- `pulse-app/tests/test_url_policy.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## 10. Pulse page discovery and reconciliation

Nested sitemap parsing, gzip/text inventories, depth/size limits, source provenance, unavailable evidence, reconciliation and request-time IO.

### B024

- `pulse-app/services/page_discovery.py`
- `pulse-app/services/sitemap_reconciliation.py`
- `pulse-app/tests/test_domain_readiness.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B025

- `pulse-app/tests/test_page_discovery.py`
- `pulse-app/tests/test_request_paths_no_discovery_io.py`
- `pulse-app/tests/test_single_sitemap_implementation.py`
- `pulse-app/tests/test_sitemap_reconciliation.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## 11. Pulse crawl selection and frontier

Eligibility versus discovery, ranking, page classes, budgets, delayed work, persistent frontier and duplicate decisions.

### B026

- `pulse-app/services/crawl_frontier.py`
- `pulse-app/tests/fixtures/skeena/category-sitemap.xml`
- `pulse-app/tests/fixtures/skeena/manifest.json`
- `pulse-app/tests/fixtures/skeena/news-release-sitemap1.xml`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B027

- `pulse-app/tests/fixtures/skeena/page-sitemap.xml`
- `pulse-app/tests/fixtures/skeena/sitemap_index.xml`
- `pulse-app/tests/test_skeena_crawl_frontier.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## 12. Pulse crawler and evidence

Fetch/parse/persist, robots failures, redirects, conditional requests, fingerprints, retained evidence, coverage and cooperative job controls.

### B028

- `pulse-app/crawlers/seo.py` — lines 1–400

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B029

- `pulse-app/crawlers/seo.py` — lines 401–800

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B030

- `pulse-app/crawlers/seo.py` — lines 801–1200

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B031

- `pulse-app/crawlers/seo.py` — lines 1201–1519

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B032

- `pulse-app/services/resource_outcome.py`
- `pulse-app/templates/crawl.html`
- `pulse-app/templates/ten_page_select.html`
- `pulse-app/tests/test_crawler_evidence.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## 13. Pulse GEO/AEO audit and scoring

Independent second page capture, signal evidence, unknown versus fail, weighting, applicability, page classification, aggregation and reference validity.

### B033

- `pulse-app/audits/geo_aeo/engine.py` — lines 1–400

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B034

- `pulse-app/audits/geo_aeo/engine.py` — lines 401–571

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B035

- `pulse-app/audits/geo_aeo/service.py`
- `pulse-app/services/applicability_policy.py`
- `pulse-app/services/audit_execution.py`
- `pulse-app/services/page_types.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B036

- `pulse-app/static/page-geo-aeo.js`
- `pulse-app/templates/geo_aeo.html`
- `pulse-app/templates/geo_aeo_integrated.html`
- `pulse-app/templates/geo_aeo_report.html`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B037

- `pulse-app/tests/test_applicability_policy.py`
- `pulse-app/tests/test_no_direct_audit_http.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## 14. Pulse manual AI evidence and analysis

Raw pasted evidence, parsing, phase/state/provider denominators, question governance, provider settings, prompt grounding and stale-analysis protection.

### B038

- `pulse-app/reports/cross_model.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B039

- `pulse-app/reports/manual_ai_analysis.py`
- `pulse-app/reports/question_governance.py`
- `pulse-app/services/manual_ai_payload.py`
- `pulse-app/services/manual_ai_report.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B040

- `pulse-app/services/manual_ai_sources.py`
- `pulse-app/templates/manual_ai_responses.html`
- `pulse-app/tests/test_manual_ai_payload.py`
- `pulse-app/tests/test_manual_ai_report_view.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## 15. Pulse source selection and paid integration

Selected versus available sources, provider errors, kill switch, credential handling, cost behavior and captured provenance.

### B041

- `pulse-app/integrations/dataforseo/connector.py`
- `pulse-app/integrations/dataforseo/extension.py`
- `pulse-app/reports/extended_sources.py`
- `pulse-app/services/source_inventory.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B042

- `pulse-app/templates/dataforseo.html`
- `pulse-app/templates/sources.html`
- `pulse-app/tests/test_dataforseo_settings_regression.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## 16. Pulse report collection and immutable sessions

Crawl/audit execution linkage, source dates, snapshot content, historical stability, current pointer and monitoring inventory.

### B043

- `pulse-app/reports/web_report.py` — lines 1–400

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B044

- `pulse-app/reports/web_report.py` — lines 401–800

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B045

- `pulse-app/reports/web_report.py` — lines 801–961

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B046

- `pulse-app/services/report_data.py`
- `pulse-app/tests/test_historical_report_immutability.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## 17. Pulse findings, history and prioritization

Finding identity, missing versus resolved, comparisons, confidence, root-cause deduplication, priority and unsupported business claims.

### B047

- `pulse-app/reports/prioritization.py`
- `pulse-app/reports/pulse_history.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B048

- `pulse-app/reports/report_intelligence.py`
- `pulse-app/tests/test_pulse_history.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B049

- `pulse-app/tests/test_report_intelligence.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## 18. Pulse report presentation and export

HTML/JS escaping, discussions, permissions, PDF/dataset parity, locale transformations, skin isolation and historical navigation.

### B050

- `pulse-app/reports/__init__.py`
- `pulse-app/reports/full_pdf.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B051

- `pulse-app/reports/localization.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B052

- `pulse-app/reports/localization_es_detectors.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B053

- `pulse-app/reports/observation_export.py`
- `pulse-app/services/report_collaboration.py`
- `pulse-app/static/analysis-markdown.js`
- `pulse-app/static/collapsible-notes.js`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B054

- `pulse-app/static/skins/default.css`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B055

- `pulse-app/templates/full_report.html` — lines 1–400

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B056

- `pulse-app/templates/full_report.html` — lines 401–800

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B057

- `pulse-app/templates/full_report.html` — lines 801–1200

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B058

- `pulse-app/templates/full_report.html` — lines 1201–1600

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B059

- `pulse-app/templates/full_report.html` — lines 1601–2000

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B060

- `pulse-app/templates/full_report.html` — lines 2001–2044

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B061

- `pulse-app/templates/public_report_access.html`
- `pulse-app/templates/reports.html`
- `pulse-app/tests/test_observation_export.py`
- `pulse-app/tests/test_report_localization.py`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## 19. Pulse research and operator UI

Keyword/page assignment, CSV imports/exports, taxonomy, notes, sorting, navigation and empty/error/loading states.

### B062

- `pulse-app/static/app.css`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B063

- `pulse-app/static/nav-keyword-links.js`
- `pulse-app/static/sortable.js`
- `pulse-app/static/taxonomy.js`
- `pulse-app/templates/base.html`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B064

- `pulse-app/templates/domain_delete.html`
- `pulse-app/templates/domain_new.html`
- `pulse-app/templates/domain_settings.html`
- `pulse-app/templates/empty.html`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B065

- `pulse-app/templates/keyword_workspace.html`
- `pulse-app/templates/keywords.html`
- `pulse-app/templates/keywords_dashboard.html`
- `pulse-app/templates/overview.html`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B066

- `pulse-app/templates/page.html`
- `pulse-app/templates/page_workspace.html`
- `pulse-app/templates/pages.html`
- `pulse-app/templates/research.html`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

### B067

- `pulse-app/templates/tools.html`
- `pulse-app/templates/wanted.html`

Status: planned. Follow the shared procedure in `pulse-review-plan.md`.

## Mandatory follow-through

After the primary batches, complete C01–C08 and I01–I08 as defined in `pulse-comparison-runs.md`. The route/job matrices and report-contract completion table in `pulse-review-plan.md` are required review inputs. B001–B067 remain unchanged; file coverage alone does not close the audit.
